package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.print.*;

public class mini extends JFrame implements ActionListener {
    String pin;
    JButton buttonExit, buttonPrint;
    JLabel label1, label2, label3, label4;

    mini(String pin) {
        this.pin = pin;
        getContentPane().setBackground(new Color(255, 204, 204));
        setSize(400, 600);
        setLocation(20, 20);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(5, 5, 100, 100);
        add(image);

        label1 = new JLabel();
        label1.setBounds(20, 140, 400, 200);
        add(label1);

        label2 = new JLabel("UMURENGE SACCO");
        label2.setFont(new Font("System", Font.BOLD, 15));
        label2.setBounds(150, 20, 200, 20);
        add(label2);

        label3 = new JLabel();
        label3.setBounds(20, 80, 300, 20);
        add(label3);

        label4 = new JLabel();
        label4.setBounds(20, 400, 300, 20);
        add(label4);

        try {
            con c = new con();
            ResultSet resultSet = c.statement.executeQuery("select * from login where pin = '" + pin + "'");
            while (resultSet.next()) {
                label3.setText("Card Number:  " + resultSet.getString("card_number").substring(0, 4) + "XXXXXXXX" + resultSet.getString("card_number").substring(12));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            int balance = 0;
            con c = new con();
            ResultSet resultSet = c.statement.executeQuery("select * from bank where pin = '" + pin + "'");
            while (resultSet.next()) {
                label1.setText(label1.getText() + "<html>" + resultSet.getString("date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + resultSet.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + resultSet.getString("amount") + "<br><br><html>");

                if (resultSet.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(resultSet.getString("amount"));
                } else {
                    balance -= Integer.parseInt(resultSet.getString("amount"));
                }
            }
            label4.setText("Your Total Balance is  " + balance + "Rwf");
        } catch (Exception e) {
            e.printStackTrace();
        }

        buttonExit = new JButton("Exit");
        buttonExit.setBounds(20, 500, 100, 25);
        buttonExit.addActionListener(this);
        buttonExit.setBackground(Color.BLACK);
        buttonExit.setForeground(Color.WHITE);
        add(buttonExit);

        // Print Button
        buttonPrint = new JButton("Print");
        buttonPrint.setBounds(130, 500, 100, 25);
        buttonPrint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Initiate the print job with the provided code
                    PrinterJob job = PrinterJob.getPrinterJob();
                    job.setPrintable(new Printable() {
                        @Override
                        public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
                            if (page > 0) {
                                return NO_SUCH_PAGE;
                            }
                            Graphics2D g2d = (Graphics2D) g;
                            g2d.translate(pf.getImageableX(), pf.getImageableY());
                            g2d.scale(0.5, 0.5);  // Scale content to fit the page
                            getContentPane().printAll(g2d);  // Print the entire content pane
                            return PAGE_EXISTS;
                        }
                    });

                    boolean doPrint = job.printDialog();
                    if (doPrint) {
                        try {
                            job.print();
                        } catch (PrinterException ex) {
                            ex.printStackTrace();
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        buttonPrint.setBackground(Color.BLACK);
        buttonPrint.setForeground(Color.WHITE);
        add(buttonPrint);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
    }

    public static void main(String[] args) {
        new mini("");
    }
}
