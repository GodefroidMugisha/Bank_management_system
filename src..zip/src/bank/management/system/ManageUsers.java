package bank.management.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManageUsers extends JFrame implements ActionListener {
    // Declare components
    JButton bViewUsers, bDeleteUser, bBack;
    JTable userTable;
    DefaultTableModel tableModel;

    ManageUsers() {
        setTitle("Manage Users");

        // Title label
        JLabel label1 = new JLabel("Manage Users");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("System", Font.BOLD, 20));
        label1.setBounds(50, 20, 200, 30);
        add(label1);

        // Buttons
        bViewUsers = new JButton("View All Users");
        bViewUsers.setFont(new Font("Raleway", Font.BOLD, 16));
        bViewUsers.setBounds(50, 80, 200, 30);
        bViewUsers.setBackground(new Color(65, 125, 128));
        bViewUsers.setForeground(Color.WHITE);
        bViewUsers.addActionListener(this);
        add(bViewUsers);

        bDeleteUser = new JButton("Delete User");
        bDeleteUser.setFont(new Font("Raleway", Font.BOLD, 16));
        bDeleteUser.setBounds(50, 130, 200, 30);
        bDeleteUser.setBackground(new Color(65, 125, 128));
        bDeleteUser.setForeground(Color.WHITE);
        bDeleteUser.addActionListener(this);
        add(bDeleteUser);

        bBack = new JButton("Back");
        bBack.setFont(new Font("Raleway", Font.BOLD, 16));
        bBack.setBounds(50, 180, 200, 30);
        bBack.setBackground(new Color(65, 125, 128));
        bBack.setForeground(Color.WHITE);
        bBack.addActionListener(this);
        add(bBack);

        // Table for displaying users
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Form No");
        tableModel.addColumn("Name");
        tableModel.addColumn("Father Name");

        userTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(userTable);
        tableScrollPane.setBounds(300, 20, 450, 400);
        add(tableScrollPane);

        // Frame properties
        setLayout(null);
        setSize(800, 500);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    // Fetch and display data from the database
    private void fetchAndDisplayUsers() {
        con con = new con(); // Using the connection from Con class
        try {
            String query = "SELECT form_no, name, father_name FROM signup";
            PreparedStatement pst = con.connection.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            // Clear the table before adding new data
            tableModel.setRowCount(0);

            while (rs.next()) {
                String formno = rs.getString("form_no");
                String name = rs.getString("name");
                String fatherName = rs.getString("father_name");
                tableModel.addRow(new Object[]{formno, name, fatherName});
            }

            rs.close();
            pst.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error fetching user data: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // Delete selected user from the database and the table
    private void deleteSelectedUser() {
        int selectedRow = userTable.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a user to delete.");
            return;
        }

        String formno = tableModel.getValueAt(selectedRow, 0).toString(); // Get Form No of selected row

        con con = new con();
        try {
            String query = "DELETE FROM signup WHERE form_no = ?";
            PreparedStatement pst = con.connection.prepareStatement(query);
            pst.setString(1, formno);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "User deleted successfully.");
                tableModel.removeRow(selectedRow); // Remove row from table
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete user.");
            }

            pst.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error deleting user: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bViewUsers) {
            fetchAndDisplayUsers();
        } else if (e.getSource() == bDeleteUser) {
            deleteSelectedUser();
        } else if (e.getSource() == bBack) {
            new AdminDashboard(); // Assuming AdminDashboard is another class
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new ManageUsers();
    }
}
