
package bank.management.system;
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement; 

/**
 *
 * @author Administrator
 */
public class con {
    Connection connection;
    Statement statement;
    
    public con(){
        try{
         connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankSystem","root","");   
         statement = connection.createStatement();
            
    }
        catch(Exception e){
            e.printStackTrace();
        }
        }
    
}
