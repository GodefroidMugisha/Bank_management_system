package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboard extends JFrame implements ActionListener {
    JButton bManageUsers, bViewTransactions, bGenerateReports, bExit;

    AdminDashboard() {
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(90, 5, 100, 100);
        add(image);
        
        setTitle("UMURENGE SACCO");

        JLabel label1 = new JLabel("UMURENGE SACCO MANAGEMENT");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("System", Font.BOLD, 20));
        label1.setBounds(220, 50, 400, 30);
        add(label1);

        bManageUsers = new JButton("Manage Users");
        bManageUsers.setFont(new Font("Raleway", Font.BOLD, 16));
        bManageUsers.setBounds(250, 150, 200, 30);
        bManageUsers.setBackground(new Color(65, 125, 128));
        bManageUsers.setForeground(Color.WHITE);
        bManageUsers.addActionListener(this);
        add(bManageUsers);

        bViewTransactions = new JButton("View Transactions");
        bViewTransactions.setFont(new Font("Raleway", Font.BOLD, 16));
        bViewTransactions.setBounds(250, 200, 200, 30);
        bViewTransactions.setBackground(new Color(65, 125, 128));
        bViewTransactions.setForeground(Color.WHITE);
        bViewTransactions.addActionListener(this);
        add(bViewTransactions);

        bGenerateReports = new JButton("Generate Reports");
        bGenerateReports.setFont(new Font("Raleway", Font.BOLD, 16));
        bGenerateReports.setBounds(250, 250, 200, 30);
        bGenerateReports.setBackground(new Color(65, 125, 128));
        bGenerateReports.setForeground(Color.WHITE);
        bGenerateReports.addActionListener(this);
        add(bGenerateReports);

        bExit = new JButton("Exit");
        bExit.setFont(new Font("Raleway", Font.BOLD, 16));
        bExit.setBounds(250, 300, 200, 30);
        bExit.setBackground(new Color(65, 125, 128));
        bExit.setForeground(Color.WHITE);
        bExit.addActionListener(this);
        add(bExit);

        setLayout(null);
        setSize(800, 520);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bManageUsers) {
            new ManageUsers();
        } else if (e.getSource() == bViewTransactions) {
            new ViewTransactions();
        } else if (e.getSource() == bGenerateReports) {
            new GenerateReports();
        } else if (e.getSource() == bExit) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }
}
