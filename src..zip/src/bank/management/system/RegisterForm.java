package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterForm extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton submitButton, backButton;

    RegisterForm() {
        setTitle("UMURENGE SACCO - Admin Registration");

        JLabel titleLabel = new JLabel("UMURENGE SACCO - Admin Registration");
        titleLabel.setFont(new Font("System", Font.BOLD, 18));
        titleLabel.setBounds(200, 30, 400, 30);
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Raleway", Font.BOLD, 16));
        usernameLabel.setForeground(Color.WHITE);
        usernameLabel.setBounds(200, 100, 100, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setFont(new Font("Arial", Font.BOLD, 14));
        usernameField.setBounds(300, 100, 200, 30);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Raleway", Font.BOLD, 16));
        passwordLabel.setForeground(Color.WHITE);
        passwordLabel.setBounds(200, 150, 100, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.BOLD, 14));
        passwordField.setBounds(300, 150, 200, 30);
        add(passwordField);

        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Raleway", Font.BOLD, 16));
        submitButton.setBounds(250, 250, 100, 30);
        submitButton.setBackground(new Color(65, 125, 128));
        submitButton.setForeground(Color.WHITE);
        submitButton.addActionListener(this);
        add(submitButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Raleway", Font.BOLD, 16));
        backButton.setBounds(400, 250, 100, 30);
        backButton.setBackground(new Color(65, 125, 128));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(this);
        add(backButton);

        setLayout(null);
        setSize(800, 520);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields!");
            } else {
                try {
                    con c = new con();
                    String query = "INSERT INTO admin (username, password) VALUES ('" + username + "', '" + password + "')";
                    c.statement.executeUpdate(query);

                    // Display success message
                    JOptionPane.showMessageDialog(null, "Admin registered successfully!");

                    // Redirect to AdminLogin
                    setVisible(false);
                    new AdminLogin(); // Redirects to the AdminLogin screen
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else if (e.getSource() == backButton) {
            // Redirect back to AdminLogin
            new AdminLogin();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new RegisterForm();
    }
}
