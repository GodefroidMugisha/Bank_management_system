/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Administrator
 */
public class Signup2 extends JFrame implements ActionListener{
    JComboBox combobox,combobox2,combobox3,combobox4,combobox5;
    JTextField textTin,textnid;
    JRadioButton r1,r2,e1,e2;
    JButton next;
    String formno;
    
    Signup2(String formno){
        super("APPLICATION FORM");
        
         ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(150, 5, 100, 100);
        add(image);
       
        this.formno = formno;
        
       JLabel l1= new JLabel("Page 2:-");
       l1.setFont(new Font("Raleway",Font.BOLD,22));
       l1.setBounds(300, 30, 600, 40);
       add(l1);
       
       JLabel l2 = new JLabel("Additional Details");
       l2.setFont(new Font("Raleway",Font.BOLD,22));
       l2.setBounds(300, 60, 600, 40);
       add(l2);
       
       JLabel l3 = new JLabel("Religion:");
       l3.setFont(new Font("Raleway",Font.BOLD,18));
       l3.setBounds(176, 120, 100, 30);
       add(l3);
       
       String religion[]={"Jehovahs witness","Adventist of 7th day","Cathoric","Muslim","Other"};
       combobox =new JComboBox(religion);
       combobox.setBackground(new Color(252,208,76));
       combobox.setFont(new Font("Raleway",Font.BOLD,14));
       combobox.setBounds(300,120,320,30);
       add(combobox);
       
       JLabel l4 = new JLabel("Category: ");
       l4.setFont(new Font("Raleway",Font.BOLD,18));
       l4.setBounds(167, 170, 100, 30);
       add(l4);
       
       String Category[]={"Category 1","Category 2","Category 3","Category 4"};
       combobox2 =new JComboBox(Category);
       combobox2.setBackground(new Color(252,208,76));
       combobox2.setFont(new Font("Raleway",Font.BOLD,14));
       combobox2.setBounds(300,170,320,30);
       add(combobox2);
       
       JLabel l5 = new JLabel("Income: ");
       l5.setFont(new Font("Raleway",Font.BOLD,18));
       l5.setBounds(182, 220, 100, 30);
       add(l5);
       
       String income[]={"Null","<500,000","<1,000,000","upto 5,000,000","Above 5,000,000"};
       combobox3 =new JComboBox(income);
       combobox3.setBackground(new Color(252,208,76));
       combobox3.setFont(new Font("Raleway",Font.BOLD,14));
       combobox3.setBounds(300,220,320,30);
       add(combobox3);
       
       JLabel l6 = new JLabel("Educational: ");
       l6.setFont(new Font("Raleway",Font.BOLD,18));
       l6.setBounds(145, 270, 130, 30);
       add(l6);
       
       String educational[]={"Non-Graduate","Graduate","Post-Graduate","Doctorate","Other"};
       combobox4 =new JComboBox(educational);
       combobox4.setBackground(new Color(252,208,76));
       combobox4.setFont(new Font("Raleway",Font.BOLD,14));
       combobox4.setBounds(300,270,320,30);
       add(combobox4);
       
       JLabel l7 = new JLabel("Occupation: ");
       l7.setFont(new Font("Raleway",Font.BOLD,18));
       l7.setBounds(149, 320, 130, 30);
       add(l7);
       
       String occupation[]={"Slaried","Self-Employed","Business","Student","Retired","Other"};
       combobox5 =new JComboBox(occupation);
       combobox5.setBackground(new Color(252,208,76));
       combobox5.setFont(new Font("Raleway",Font.BOLD,14));
       combobox5.setBounds(300,320,320,30);
       add(combobox5);
       
       JLabel l8 = new JLabel("TIN Number: ");
       l8.setFont(new Font("Raleway",Font.BOLD,18));
       l8.setBounds(135, 370, 130, 30);
       add(l8);
       
       textTin = new JTextField();
       textTin.setFont(new Font("Raleway",Font.BOLD,18));
       textTin.setBounds(300, 370, 320, 30);
       add(textTin);
       
       JLabel l9 = new JLabel("National ID: ");
       l9.setFont(new Font("Raleway",Font.BOLD,18));
       l9.setBounds(154,420, 130, 30);
       add(l9);
       
       textnid = new JTextField();
       textnid.setFont(new Font("Raleway",Font.BOLD,18));
       textnid.setBounds(300,420, 320, 30);
       add(textnid);
        
       JLabel l10 = new JLabel("Senior Citizen: ");
       l10.setFont(new Font("Raleway",Font.BOLD,18));
       l10.setBounds(125,470, 160, 30);
       add(l10);
       
       r1 = new JRadioButton("Yes");
       r1.setFont(new Font("Raleway",Font.BOLD,14));
       r1.setBackground(new Color(252,208,76));
       r1.setBounds(300, 470, 70, 30);
       add(r1);
       
       r2 = new JRadioButton("No");
       r2.setFont(new Font("Raleway",Font.BOLD,14));
       r2.setBackground(new Color(252,208,76));
       r2.setBounds(410, 470, 70, 30);
       add(r2);
       
       JLabel l11 = new JLabel("Existing Account: ");
       l11.setFont(new Font("Raleway",Font.BOLD,18));
       l11.setBounds(100,520, 160, 30);
       add(l11);
       
       e1 = new JRadioButton("Yes");
       e1.setFont(new Font("Raleway",Font.BOLD,14));
       e1.setBackground(new Color(252,208,76));
       e1.setBounds(300, 520, 70, 30);
       add(e1);
       
       e2 = new JRadioButton("No");
       e2.setFont(new Font("Raleway",Font.BOLD,14));
       e2.setBackground(new Color(252,208,76));
       e2.setBounds(410, 520, 70, 30);
       add(e2);
       
       JLabel l12 = new JLabel("Form No: ");
       l12.setFont(new Font("Raleway",Font.BOLD,18));
       l12.setBounds(650,10, 180, 30);
       add(l12);
       
       JLabel l13 = new JLabel(formno);
       l13.setFont(new Font("Raleway",Font.BOLD,18));
       l13.setBounds(760,10, 60, 30);
       add(l13);
       
       next = new JButton("Next");
       next.setFont(new Font("Raleway",Font.BOLD,14));
       next.setBackground(Color.WHITE);
       next.setForeground(Color.BLACK);
       next.setBounds(570,600,100,30);
       next.addActionListener(this);
       add(next);
        
        setLayout(null);
        setSize(850,700);
        setLocation(360,5);
        getContentPane().setBackground(new Color(252,208,76));
        setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        String rel = (String)combobox.getSelectedItem();
        String cate = (String)combobox2.getSelectedItem();
        String inc = (String)combobox3.getSelectedItem();
        String edu = (String)combobox4.getSelectedItem();
        String occ = (String)combobox5.getSelectedItem();
        
        String tin= textTin.getText();
        String id=textnid.getText();
        
        String scitizen="";
        if(r1.isSelected()){
            scitizen="Yes";
        }else if(r2.isSelected()){
            scitizen="No";
        }
        String eaccount="";
        if(r1.isSelected()){
            eaccount="Yes";
        }else if(r2.isSelected()){
            eaccount="No";
        }
        try{
            if(textTin.getText().equals("") || textnid.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the fields");
            }else{
               con c1=new con();
               String q="insert into signuptwo values('"+formno+"','"+rel+"','"+cate+"','"+inc+"','"+edu+"','"+occ+"','"+tin+"','"+id+"','"+scitizen+"','"+eaccount+"')";
               c1.statement.executeUpdate(q);
               new Signup3(formno);
               setVisible(false);
            }
            
        }catch(Exception E){
            E.printStackTrace();
        }
        
        
    }
    public static void main(String[] args){
        new Signup2("");
    }
    
    
}
