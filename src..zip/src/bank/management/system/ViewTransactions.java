package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class ViewTransactions extends JFrame implements ActionListener {
    JButton bBack;
    JTable table;
    JScrollPane sp;

    ViewTransactions() {
        setTitle("View Transactions");

        // Table setup
        String[] columnNames = {"User PIN", "Transaction Type", "Amount", "Date"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        sp = new JScrollPane(table);
        sp.setBounds(50, 100, 700, 300);
        add(sp);

        bBack = new JButton("Back");
        bBack.setFont(new Font("Raleway", Font.BOLD, 16));
        bBack.setBounds(350, 420, 100, 30);
        bBack.setBackground(new Color(65, 125, 128));
        bBack.setForeground(Color.WHITE);
        bBack.addActionListener(this);
        add(bBack);

        // Fetch data from the database
        fetchTransactions();

        // Frame settings
        setLayout(null);
        setSize(800, 520);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    // Fetch transaction data from the database
    public void fetchTransactions() {
        try {
            con con1 = new con();
            String query = "SELECT pin, type, amount, date FROM bank";
            ResultSet rs = con1.statement.executeQuery(query);

            while (rs.next()) {
                String userPin = rs.getString("pin");
                String transactionType = rs.getString("type");
                String amount = rs.getString("amount");
                String date = rs.getString("date");

                // Adding rows to the table
                String[] row = {userPin, transactionType, amount, date};
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bBack) {
            new AdminDashboard(); // Assuming AdminDashboard is implemented
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new ViewTransactions();
    }
}
