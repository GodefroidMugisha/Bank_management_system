package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GenerateReports extends JFrame implements ActionListener {
    JButton bGenerate, bBack;
    JSpinner startDateSpinner, endDateSpinner;

    GenerateReports() {
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(90, 5, 100, 100);
        add(image);
        setTitle("Generate Reports");

        // Report Title
        JLabel label1 = new JLabel("Generate Reports");
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("System", Font.BOLD, 20));
        label1.setBounds(330, 50, 200, 30);
        add(label1);

        JLabel label2 = new JLabel("Start Date: ");
        label2.setForeground(Color.WHITE);
        label2.setFont(new Font("System", Font.BOLD, 16));
        label2.setBounds(200, 150, 200, 30);
        add(label2);

        // Spinner for Start Date
        startDateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor startEditor = new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd");
        startDateSpinner.setEditor(startEditor);
        startDateSpinner.setBounds(310, 150, 200, 30);
        add(startDateSpinner);

        JLabel label3 = new JLabel("End Date: ");
        label3.setForeground(Color.WHITE);
        label3.setFont(new Font("System", Font.BOLD, 16));
        label3.setBounds(200, 200, 200, 30);
        add(label3);

        // Spinner for End Date
        endDateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor endEditor = new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd");
        endDateSpinner.setEditor(endEditor);
        endDateSpinner.setBounds(310, 200, 200, 30);
        add(endDateSpinner);

        // Enlarged Generate Button
        bGenerate = new JButton("Generate");
        bGenerate.setFont(new Font("Raleway", Font.BOLD, 16));
        bGenerate.setBounds(220, 350, 150, 40);
        bGenerate.setBackground(new Color(65, 125, 128));
        bGenerate.setForeground(Color.WHITE);
        bGenerate.addActionListener(this);
        add(bGenerate);

        // Back Button
        bBack = new JButton("Back");
        bBack.setFont(new Font("Raleway", Font.BOLD, 16));
        bBack.setBounds(400, 350, 150, 40);
        bBack.setBackground(new Color(65, 125, 128));
        bBack.setForeground(Color.WHITE);
        bBack.addActionListener(this);
        add(bBack);

        setLayout(null);
        setSize(800, 520);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bGenerate) {
            // Fetching dates from spinners
            Date startDate = (Date) startDateSpinner.getValue();
            Date endDate = (Date) endDateSpinner.getValue();

            // Validating date range
            if (startDate.after(endDate)) {
                JOptionPane.showMessageDialog(null, "Start date cannot be after end date!");
                return;
            }

            // Fetch and display report
            fetchAndDisplayReport(startDate, endDate);
        } else if (e.getSource() == bBack) {
            new AdminDashboard();
            setVisible(false);
        }
    }

    private void fetchAndDisplayReport(Date startDate, Date endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String start = sdf.format(startDate);
        String end = sdf.format(endDate);

        StringBuilder report = new StringBuilder();
        report.append("Transactions Report from ").append(start).append(" to ").append(end).append(":\n\n");

        try {
            // Database connection (self-contained)
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankSystem","root","");

            // SQL query to fetch data within the specified date range
            String query = "SELECT pin, type, amount, date FROM bank WHERE DATE(date) BETWEEN ? AND ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, start);
            pstmt.setString(2, end);

            ResultSet rs = pstmt.executeQuery();

            boolean dataExists = false;
            while (rs.next()) {
                String pin = rs.getString("pin");
                String type = rs.getString("type");
                String amount = rs.getString("amount");
                String date = rs.getString("date");

                // Append transaction details to the report
                report.append("PIN: ").append(pin)
                      .append(", Type: ").append(type)
                      .append(", Amount: ").append(amount)
                      .append(", Date: ").append(date)
                      .append("\n");

                dataExists = true;
            }

            if (!dataExists) {
                report.append("No transactions found within this date range.");
            }

            // Close connection
            rs.close();
            pstmt.close();
            connection.close();

            // Display the report
            JOptionPane.showMessageDialog(null, report.toString(), "Transaction Report", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "An error occurred while generating the report!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new GenerateReports();
    }
}
