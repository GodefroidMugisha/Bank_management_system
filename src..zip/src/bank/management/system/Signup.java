package bank.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Random;
import javax.swing.*;
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement; 

public class Signup extends JFrame implements ActionListener {
    JRadioButton r1,r2,m1,m2,m3;
    JButton next;

    JTextField textName, textFname,textEmail,textAdd,textCity,textPin,textState;
    JComboBox<String> dayBox, monthBox, yearBox;
    Random ran = new Random();

    // Generate a 4-digit random application form number
    long first4 = (Math.abs(ran.nextLong()) % 9000L) + 1000L;
    String first = "" + first4;

    Signup() {
        super("APPLICATION FORM");

        // Load and set the bank logo
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(25, 10, 100, 100);
        add(image);

        // Application form label
        JLabel label1 = new JLabel("APPLICATION FORM NO. " + first);
        label1.setBounds(160, 20, 600, 40);
        label1.setFont(new Font("Raleway", Font.BOLD, 38));
        add(label1);

        // Page label
        JLabel label2 = new JLabel("Page 1");
        label2.setFont(new Font("Raleway", Font.BOLD, 22));
        label2.setBounds(330, 70, 600, 30);
        add(label2);

        // Personal details label
        JLabel label3 = new JLabel("Personal Details");
        label3.setFont(new Font("Raleway", Font.BOLD, 22));
        label3.setBounds(290, 100, 600, 30);
        add(label3);

        // Name label and text field
        JLabel labelName = new JLabel("Name:");
        labelName.setFont(new Font("Raleway", Font.BOLD, 20));
        labelName.setBounds(182, 160, 100, 30);
        add(labelName);

        textName = new JTextField();
        textName.setFont(new Font("Raleway", Font.BOLD, 14));
        textName.setBounds(300, 160, 400, 30);
        add(textName);

        // Father's name label and text field
        JLabel labelfName = new JLabel("Father's Name:");
        labelfName.setFont(new Font("Raleway", Font.BOLD, 20));
        labelfName.setBounds(100, 210, 200, 30);
        add(labelfName);

        textFname = new JTextField();
        textFname.setFont(new Font("Raleway", Font.BOLD, 14));
        textFname.setBounds(300, 210, 400, 30);
        add(textFname);
        
        //Gender label
       JLabel labelG = new JLabel("Gender:");
       labelG.setFont(new Font("Raleway",Font.BOLD,20));
       labelG.setBounds(165, 265, 200, 30);
       add(labelG);
       
        //choice of Gender
         r1 = new JRadioButton("Male");
        r1.setFont(new Font("Raleway", Font.BOLD, 14));
        r1.setBackground(new Color(222,255,228));
        r1.setBounds(300,265,60,30);
        add(r1);
        
         r2 = new JRadioButton("Female");
        r2.setFont(new Font("Raleway", Font.BOLD, 14));
        r2.setBackground(new Color(222,255,228));
        r2.setBounds(450,265,90,30);
        add(r2);
        
        ButtonGroup buttonGroup=new ButtonGroup();
        buttonGroup.add(r1);
        buttonGroup.add(r2);
        
         // Date of birth label and dropdowns
        JLabel DOB = new JLabel("Date Of Birth:");
        DOB.setFont(new Font("Raleway", Font.BOLD, 20));
        DOB.setBounds(113, 315, 200, 30);
        add(DOB);

        // Day ComboBox
        String[] days = new String[31];
        for (int i = 1; i <= 31; i++) {
            days[i - 1] = String.valueOf(i);
        }
        dayBox = new JComboBox<>(days);
        dayBox.setBounds(300, 315, 60, 30);
        add(dayBox);

        // Month ComboBox
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        monthBox = new JComboBox<>(months);
        monthBox.setBounds(370, 315, 100, 30);
        add(monthBox);

        // Year ComboBox
        String[] years = new String[100];
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = 0; i < 100; i++) {
            years[i] = String.valueOf(currentYear - i);
        }
        yearBox = new JComboBox<>(years);
        yearBox.setBounds(480, 315, 80, 30);
        add(yearBox);
        //email address
        JLabel labelEmail = new JLabel("Email address:");
        labelEmail.setFont(new Font("Raleway", Font.BOLD, 20));
        labelEmail.setBounds(104,360,200,30);
        add(labelEmail);
        
        textEmail = new JTextField();
        textEmail.setFont(new Font("Raleway", Font.BOLD, 14));
        textEmail.setBounds(300, 360, 400, 30);
        add(textEmail);
        
        //marital status
        JLabel labelMs = new JLabel("Marital Status:");
        labelMs.setFont(new Font("Raleway", Font.BOLD, 20));
        labelMs.setBounds(106,410,200,30);
        add(labelMs);
        
        m1= new JRadioButton("Married");
        m1.setBounds(300,410,100,30);
        m1.setBackground(new Color(222,255,228));
        m1.setFont(new Font("Raleway",Font.BOLD,14));
        add(m1);
        
         m2= new JRadioButton("Unmarried");
        m2.setBounds(450,410,100,30);
        m2.setBackground(new Color(222,255,228));
        m2.setFont(new Font("Raleway",Font.BOLD,14));
        add(m2);
        
         m3= new JRadioButton("Other");
        m3.setBounds(635,410,100,30);
        m3.setBackground(new Color(222,255,228));
        m3.setFont(new Font("Raleway",Font.BOLD,14));
        add(m3);
        
        ButtonGroup buttonGroup1 = new ButtonGroup();
        buttonGroup1.add(m1);
        buttonGroup1.add(m2);
        buttonGroup1.add(m3);
        //address
         JLabel labelAdd = new JLabel("Address:");
        labelAdd.setFont(new Font("Raleway", Font.BOLD, 20));
        labelAdd.setBounds(156,460,200,30);
        add(labelAdd);
        
        textAdd = new JTextField();
        textAdd.setFont(new Font("Raleway", Font.BOLD, 14));
        textAdd.setBounds(300, 460, 400, 30);
        add(textAdd);
        
        //city address
         JLabel labelCity = new JLabel("City:");
        labelCity.setFont(new Font("Raleway", Font.BOLD, 20));
        labelCity.setBounds(196,510,200,30);
        add(labelCity);
        
        textCity = new JTextField();
        textCity.setFont(new Font("Raleway", Font.BOLD, 14));
        textCity.setBounds(300, 510, 400, 30);
        add(textCity);
        
        //Pin
         JLabel labelPin = new JLabel("Pin Code:");
        labelPin.setFont(new Font("Raleway", Font.BOLD, 20));
        labelPin.setBounds(150,560,200,30);
        add(labelPin);
        
        textPin = new JTextField();
        textPin.setFont(new Font("Raleway", Font.BOLD, 14));
        textPin.setBounds(300, 560, 400, 30);
        add(textPin);
        
        //state
         JLabel labelState = new JLabel("Province:");
        labelState.setFont(new Font("Raleway", Font.BOLD, 20));
        labelState.setBounds(153,610,200,30);
        add(labelState);
        
        textState = new JTextField();
        textState.setFont(new Font("Raleway", Font.BOLD, 14));
        textState.setBounds(300, 610, 400, 30);
        add(textState);
        
        //next button
        next=new JButton("Next");
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(620, 655, 80, 30);
        next.addActionListener(this);
        add(next);
        

        // Frame settings
        getContentPane().setBackground(new Color(222, 255, 228));
        setLayout(null);
        setSize(850, 780);
        setLocation(360, 3);
        setVisible(true);
        
    }
    @Override
        public void actionPerformed(ActionEvent e){
        
            String formno= first;
            String name = textName.getText();
            String fname = textFname.getText();
            // Get selected values from ComboBoxes
            String day = (String) dayBox.getSelectedItem();
            String month = (String) monthBox.getSelectedItem();
            String year = (String) yearBox.getSelectedItem();

            // Combine them into a single string in the format "DD-MMM-YYYY"
            String dob = day + "-" + month + "-" + year;
            
            String gender =null;
            if(r1.isSelected()){
                gender= "Male";
                
            }
            else if(r2.isSelected()){
                gender="Female";
            }
            String email = textEmail.getText();
            String marital = null;
            if(m1.isSelected()){
               marital= "Married"; 
            }
            else if(m2.isSelected()){
                marital="Unmarried";
            }
            else if(m3.isSelected()){
                marital="Other";
            }
            String address = textAdd.getText();
            String city = textCity.getText();
            String pincode = textPin.getText();
            String province = textState.getText();
            
            try{
            if(textName.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Fill all the fields");
            }else {
                con con1 =new con();
                String q= "insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+marital+"','"+address+"','"+city+"','"+pincode+"','"+province+"')";
                con1.statement.executeUpdate(q);
                new Signup2(formno);
                setVisible(false);
            }

    }catch(Exception E){
        E.printStackTrace();
    }
        
    }

    public static void main(String[] args) {
        new Signup();
    }
}
