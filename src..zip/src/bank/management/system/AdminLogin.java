package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminLogin extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, registerButton, backButton;

    AdminLogin() {
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.JPEG"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(120, 5, 100, 100);
        add(image);
        
        
        setTitle("UMURENGE SACCO - Admin Login");

        JLabel titleLabel = new JLabel("UMURENGE SACCO Admin Login");
        titleLabel.setFont(new Font("System", Font.BOLD, 20));
        titleLabel.setBounds(230, 50, 400, 30);
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Raleway", Font.BOLD, 16));
        usernameLabel.setBounds(200, 150, 100, 30);
        usernameLabel.setForeground(Color.WHITE);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setFont(new Font("Arial", Font.BOLD, 14));
        usernameField.setBounds(310, 150, 200, 30);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Raleway", Font.BOLD, 16));
        passwordLabel.setBounds(200, 200, 100, 30);
        passwordLabel.setForeground(Color.WHITE);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Arial", Font.BOLD, 14));
        passwordField.setBounds(310, 200, 200, 30);
        add(passwordField);

        // Buttons aligned horizontally
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Raleway", Font.BOLD, 16));
        loginButton.setBounds(210, 300, 100, 30);
        loginButton.setBackground(new Color(65, 125, 128));
        loginButton.setForeground(Color.WHITE);
        loginButton.addActionListener(this);
        add(loginButton);

        registerButton = new JButton("Register");
        registerButton.setFont(new Font("Raleway", Font.BOLD, 16));
        registerButton.setBounds(330, 300, 100, 30);
        registerButton.setBackground(new Color(65, 125, 128));
        registerButton.setForeground(Color.WHITE);
        registerButton.addActionListener(this);
        add(registerButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Raleway", Font.BOLD, 16));
        backButton.setBounds(450, 300, 100, 30);
        backButton.setBackground(new Color(65, 125, 128));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(this);
        add(backButton);

        setLayout(null);
        setSize(800, 520);
        setLocation(300, 100);
        getContentPane().setBackground(new Color(65, 125, 128));
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields!");
            } else {
                try {
                    con c = new con();
                    String query = "SELECT * FROM admin WHERE username = ? AND password = ?";
                    PreparedStatement ps = c.connection.prepareStatement(query);
                    ps.setString(1, username);
                    ps.setString(2, password);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        JOptionPane.showMessageDialog(null, "Login Successful!");
                        setVisible(false);
                        new AdminDashboard();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } else if (e.getSource() == registerButton) {
            new RegisterForm(); // Open the registration form
            setVisible(false);
        } else if (e.getSource() == backButton) {
            // Handle back action (return to a previous screen, if applicable)
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new AdminLogin();
    }
}
